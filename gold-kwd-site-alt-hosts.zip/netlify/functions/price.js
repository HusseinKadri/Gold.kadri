// netlify/functions/price.js — Netlify Functions (Node 18)
exports.handler = async function(event, context) {
  const headers = { 'content-type': 'application/json', 'cache-control': 'public, max-age=30' };

  const withTimeout = (p, ms=8000) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);

  const tryGoldAPI = async () => {
    const key = process.env.GOLDAPI_KEY;
    if (!key) throw new Error('no key');
    const resp = await withTimeout(fetch('https://www.goldapi.io/api/XAU/KWD', { headers: { 'x-access-token': key, 'Accept': 'application/json' } }));
    if (!resp.ok) throw new Error('goldapi http ' + resp.status);
    const j = await resp.json();
    if (typeof j.price !== 'number' || !isFinite(j.price)) throw new Error('goldapi bad payload');
    return { xau_oz_kwd: j.price, provider: 'GoldAPI.io', as_of_iso: new Date().toISOString() };
  };

  const tryMetalsAPI = async () => {
    const key = process.env.METALS_API_KEY;
    if (!key) throw new Error('no key');
    const url = `https://metals-api.com/api/latest?access_key=${encodeURIComponent(key)}&base=XAU&symbols=KWD`;
    const resp = await withTimeout(fetch(url));
    if (!resp.ok) throw new Error('metals-api http ' + resp.status);
    const j = await resp.json();
    const val = j && j.rates && j.rates.KWD;
    if (typeof val !== 'number' || !isFinite(val)) throw new Error('metals-api bad payload');
    const asOf = j.timestamp ? new Date(j.timestamp * 1000).toISOString() : new Date().toISOString();
    return { xau_oz_kwd: val, provider: 'Metals-API', as_of_iso: asOf };
  };

  const tryMetalsLive = async () => {
    const resp = await withTimeout(fetch('https://api.metals.live/v1/spot'));
    if (!resp.ok) throw new Error('metals.live http ' + resp.status);
    const arr = await resp.json();
    const usdPrice = Array.isArray(arr) ? (arr.find(o => typeof o.gold === 'number')?.gold) : null;
    if (typeof usdPrice !== 'number' || !isFinite(usdPrice)) throw new Error('metals.live bad payload');
    const fxResp = await withTimeout(fetch('https://api.exchangerate.host/latest?base=USD&symbols=KWD'));
    if (!fxResp.ok) throw new Error('fx http ' + fxResp.status);
    const fx = await fxResp.json();
    const usd2kwd = fx && fx.rates && fx.rates.KWD;
    if (typeof usd2kwd !== 'number' || !isFinite(usd2kwd)) throw new Error('fx bad payload');
    const kwdPrice = usdPrice * usd2kwd;
    return { xau_oz_kwd: kwdPrice, provider: 'metals.live + exchangerate.host', as_of_iso: new Date().toISOString() };
  };

  try {
    const result = await tryGoldAPI().catch(tryMetalsAPI).catch(tryMetalsLive);
    return { statusCode: 200, headers, body: JSON.stringify(result) };
  } catch (e) {
    return { statusCode: 503, headers, body: JSON.stringify({ error: 'All providers failed', detail: String(e) }) };
  }
};
