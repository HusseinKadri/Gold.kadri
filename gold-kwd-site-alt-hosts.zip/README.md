# Gold KWD

Minimal placeholder README.

## GitHub Actions
انشر تلقائيًا إلى Vercel عبر ملف العمل في `.github/workflows/deploy.yml`. أضف أسرار `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`.

---

## خيار بديل بدون Vercel: Cloudflare Pages (مُوصى به)

1) أنشئ حساب Cloudflare ثم **Pages → Create a project → Connect to Git** واختر مستودع GitHub.  
2) اترك إعدادات البناء الافتراضية (مشروع Static).  
3) ضمن **Settings → Environment variables** أضِف:
   - `GOLDAPI_KEY`
   - `METALS_API_KEY`
4) وظيفة `/api/price` مُنفّذة في **`functions/api/price.js`**. لا تحتاج أي إعداد إضافي؛ المسار يصبح `/api/price` تلقائيًا.
5) ادفع (push) إلى `main` وسيُنشَر الموقع.

## خيار بديل: Netlify

1) اربط مستودع GitHub مع Netlify.  
2) ضمن **Site settings → Environment variables** أضِف: `GOLDAPI_KEY`, `METALS_API_KEY`.  
3) الملف **`netlify/functions/price.js`** يوفّر المسار `/api/price` عبر التوجيه المعرّف في `netlify.toml`.
4) كل دفع إلى `main` سيبني وينشر تلقائيًا.
