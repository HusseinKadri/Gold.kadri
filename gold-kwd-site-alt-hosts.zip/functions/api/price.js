// functions/api/price.js — Cloudflare Pages Functions (Web standard runtime)
export async function onRequest(context) {
  const { env } = context;
  const headers = { 'content-type': 'application/json', 'cache-control': 's-maxage=30, stale-while-revalidate=30' };

  const withTimeout = async (url, init={}, ms=8000) => {
    const ctrl = new AbortController();
    const id = setTimeout(() => ctrl.abort('timeout'), ms);
    try {
      const resp = await fetch(url, { ...init, signal: ctrl.signal });
      return resp;
    } finally {
      clearTimeout(id);
    }
  };

  const tryGoldAPI = async () => {
    const key = env.GOLDAPI_KEY;
    if (!key) throw new Error('no key');
    const resp = await withTimeout('https://www.goldapi.io/api/XAU/KWD', {
      headers: { 'x-access-token': key, 'Accept': 'application/json' }
    });
    if (!resp.ok) throw new Error('goldapi http ' + resp.status);
    const j = await resp.json();
    if (typeof j.price !== 'number' || !isFinite(j.price)) throw new Error('goldapi bad payload');
    return { xau_oz_kwd: j.price, provider: 'GoldAPI.io', as_of_iso: new Date().toISOString() };
  };

  const tryMetalsAPI = async () => {
    const key = env.METALS_API_KEY;
    if (!key) throw new Error('no key');
    const url = `https://metals-api.com/api/latest?access_key=${encodeURIComponent(key)}&base=XAU&symbols=KWD`;
    const resp = await withTimeout(url);
    if (!resp.ok) throw new Error('metals-api http ' + resp.status);
    const j = await resp.json();
    const val = j && j.rates && j.rates.KWD;
    if (typeof val !== 'number' || !isFinite(val)) throw new Error('metals-api bad payload');
    const asOf = j.timestamp ? new Date(j.timestamp * 1000).toISOString() : new Date().toISOString();
    return { xau_oz_kwd: val, provider: 'Metals-API', as_of_iso: asOf };
  };

  const tryMetalsLive = async () => {
    const resp = await withTimeout('https://api.metals.live/v1/spot');
    if (!resp.ok) throw new Error('metals.live http ' + resp.status);
    const arr = await resp.json();
    const usdPrice = Array.isArray(arr) ? (arr.find(o => typeof o.gold === 'number')?.gold) : null;
    if (typeof usdPrice !== 'number' || !isFinite(usdPrice)) throw new Error('metals.live bad payload');
    const fxResp = await withTimeout('https://api.exchangerate.host/latest?base=USD&symbols=KWD');
    if (!fxResp.ok) throw new Error('fx http ' + fxResp.status);
    const fx = await fxResp.json();
    const usd2kwd = fx && fx.rates && fx.rates.KWD;
    if (typeof usd2kwd !== 'number' || !isFinite(usd2kwd)) throw new Error('fx bad payload');
    const kwdPrice = usdPrice * usd2kwd;
    return { xau_oz_kwd: kwdPrice, provider: 'metals.live + exchangerate.host', as_of_iso: new Date().toISOString() };
  };

  try {
    const result = await tryGoldAPI().catch(tryMetalsAPI).catch(tryMetalsLive);
    return new Response(JSON.stringify(result), { headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: 'All providers failed', detail: String(e) }), { status: 503, headers });
  }
}
