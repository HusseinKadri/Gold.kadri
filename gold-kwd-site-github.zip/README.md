# Gold KWD

Minimal placeholder README.

## GitHub Actions
انشر تلقائيًا إلى Vercel عبر ملف العمل في `.github/workflows/deploy.yml`. أضف أسرار `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`.