
import { describe, it, expect } from 'vitest';
import { computeRates } from '../src/domain/services/GoldCalculator';

describe('GoldCalculator', () => {
  it('computes grams correctly', () => {
    const xauUsd = 2400;      // $2400/oz
    const usdToKwd = 0.306;   // 1 USD = 0.306 KWD
    const result = computeRates(xauUsd, usdToKwd);
    expect(result.ounceKWD).toBeCloseTo(734.4, 1);
    expect(result.perGram[24]).toBeCloseTo(23.615, 3);
    expect(result.perGram[22]).toBeCloseTo(21.633, 3);
    expect(result.perGram[21]).toBeCloseTo(20.915, 3);
    expect(result.perGram[18]).toBeCloseTo(17.711, 3);
  });
});
