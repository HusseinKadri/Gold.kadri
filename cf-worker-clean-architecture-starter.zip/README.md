
# Cloudflare Worker — Clean Architecture Starter

A minimal, testable, **Clean Architecture (Hexagonal)** template for Cloudflare Workers using **TypeScript** and **Hono**.

## Why this structure?
- **Domain (pure logic):** No imports from CF APIs. Easy to test.
- **Application (use cases):** Orchestrates the domain, talks to ports.
- **Infrastructure (adapters):** All Cloudflare/basics (HTTP, fetch, KV, etc.). Swappable.
- **Composition (DI):** Wire everything together at the boundary.

## Quick start
```bash
# 1) Install deps
npm i

# 2) Dev
npx wrangler dev

# 3) Deploy
npx wrangler deploy
```

## Routes
- `GET /health` – health check
- `GET /rates?xau=2400&usd_kwd=0.306` – compute 24k/22k/21k/18k per gram + ounce
  - Query params:
    - `xau`: price of gold **per troy ounce in USD** (e.g., 2400)
    - `usd_kwd`: USD→KWD rate (e.g., 0.306)
  - In real life you would implement a `PriceSource` adapter that fetches from
    TradingView or a data vendor; here we provide a `MockPriceSource` for demo.

## Replace the mock
See `src/infrastructure/adapters/MockPriceSource.ts`. Create your own adapter
that implements `PriceSource` and inject it in `src/infrastructure/di/container.ts`.

## Testing
```bash
npm test
```
