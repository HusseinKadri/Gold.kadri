
import { Hono } from 'hono';
import { z } from 'zod';
import type { GetRatesUseCase } from '../../application/usecases/GetRatesUseCase';

export function buildRouter(getRates: GetRatesUseCase) {
  const app = new Hono();

  app.get('/health', c => c.json({ ok: true, app: c.env.APP_NAME ?? 'worker' }));

  app.get('/rates', async c => {
    const schema = z.object({
      xau: z.coerce.number().positive().optional(),
      usd_kwd: z.coerce.number().positive().optional(),
    });

    const parsed = schema.safeParse({
      xau: c.req.query('xau'),
      usd_kwd: c.req.query('usd_kwd'),
    });

    if (!parsed.success) {
      return c.json({ error: 'Invalid query parameters', details: parsed.error.format() }, 400);
    }

    const data = await getRates.run({
      overrideXauUsd: parsed.data.xau,
      overrideUsdToKwd: parsed.data.usd_kwd,
    });

    return c.json({
      inputs: data.inputs,
      ounceKWD: data.ounceKWD,
      perGram: data.perGram,
      meta: {
        unit: 'KWD',
        source: 'MockPriceSource (replace in DI)'
      }
    });
  });

  // catch-all 404
  app.all('*', c => c.json({ error: 'Not found' }, 404));

  return app;
}
