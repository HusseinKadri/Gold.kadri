
import { MockPriceSource } from '../adapters/MockPriceSource';
import { GetRatesUseCase } from '../../application/usecases/GetRatesUseCase';

export function makeContainer() {
  const priceSource = new MockPriceSource();
  const getRates = new GetRatesUseCase(priceSource);
  return { getRates };
}
