
import type { PriceSource } from '../../application/ports/PriceSource';

/**
 * Mock stub to make the template run without external APIs.
 * Replace with a real adapter that fetches from TradingView or your provider.
 */
export class MockPriceSource implements PriceSource {
  async getXauUsd(): Promise<number> {
    // Example: $2400 per ounce
    return 2400;
  }
  async getUsdToKwd(): Promise<number> {
    // Example: 1 USD = 0.306 KWD
    return 0.306;
  }
}
