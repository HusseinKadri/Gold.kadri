
import { computeRates } from '../../domain/services/GoldCalculator';
import type { PriceSource } from '../ports/PriceSource';

export class GetRatesUseCase {
  constructor(private readonly priceSource: PriceSource) {}

  async run(params?: { overrideXauUsd?: number; overrideUsdToKwd?: number }) {
    const xauUsd = params?.overrideXauUsd ?? await this.priceSource.getXauUsd();
    const usdToKwd = params?.overrideUsdToKwd ?? await this.priceSource.getUsdToKwd();
    return computeRates(xauUsd, usdToKwd);
  }
}
