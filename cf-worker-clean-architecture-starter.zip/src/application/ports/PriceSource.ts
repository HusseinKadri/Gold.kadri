
export interface PriceSource {
  /**
   * Returns the latest gold price per troy ounce in USD.
   * Example: 2400.25
   */
  getXauUsd(): Promise<number>;

  /**
   * Returns the USD→KWD exchange rate.
   * Example: 0.306
   */
  getUsdToKwd(): Promise<number>;
}
