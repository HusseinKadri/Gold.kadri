
import { buildRouter } from './infrastructure/http/router';
import { makeContainer } from './infrastructure/di/container';

export interface Env {
  APP_NAME: string;
}

const { getRates } = makeContainer();
const app = buildRouter(getRates);

export default {
  fetch: (request: Request, env: Env, ctx: ExecutionContext) => {
    return app.fetch(request, env, ctx);
  }
};
