
export type Carat = 24 | 22 | 21 | 18;

export interface GoldRates {
  perGram: Record<Carat, number>;
  ounceKWD: number;
  inputs: {
    xauUsd: number;   // gold price per troy ounce in USD
    usdToKwd: number; // USD→KWD conversion rate
  };
}
