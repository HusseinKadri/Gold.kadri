
import type { GoldRates, Carat } from '../entities/GoldRates';

// Troy ounce in grams
const TROY_OUNCE_GRAMS = 31.1034768;

// Pure 24k gold fraction is 1. Others scale linearly by karat/24.
const KARAT_FRACTIONS: Record<Carat, number> = {
  24: 24/24,
  22: 22/24,
  21: 21/24,
  18: 18/24,
};

export function computeRates(xauUsd: number, usdToKwd: number): GoldRates {
  if (xauUsd <= 0 || usdToKwd <= 0) {
    throw new Error('Invalid inputs: xauUsd and usdToKwd must be positive.');
  }

  const ounceKWD = xauUsd * usdToKwd;
  const gram24Kwd = ounceKWD / TROY_OUNCE_GRAMS;

  const perGram = (Object.keys(KARAT_FRACTIONS) as unknown as Carat[])
    .reduce<Record<Carat, number>>((acc, k) => {
      const fraction = KARAT_FRACTIONS[k];
      acc[k] = Number((gram24Kwd * fraction).toFixed(3));
      return acc;
    }, {} as Record<Carat, number>);

  return {
    perGram,
    ounceKWD: Number(ounceKWD.toFixed(3)),
    inputs: { xauUsd, usdToKwd },
  };
}
